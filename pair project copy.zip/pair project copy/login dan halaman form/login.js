{/* <script>
let users = []; // Simpan informasi pengguna (username dan password) di sini

function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Periksa apakah pengguna ada dalam daftar
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        document.getElementById("loginForm").style.display = "none";
        document.getElementById("registerForm").style.display = "none";
        document.getElementById("welcomeMessage").style.display = "block";
        document.getElementById("loggedInUser").textContent = username;
    } else {
        alert("Login gagal. Periksa kembali username dan password Anda.");
    }
}

function register() {
    const newUsername = document.getElementById("newUsername").value;
    const newPassword = document.getElementById("newPassword").value;

    // Periksa apakah username sudah ada dalam daftar
    const existingUser = users.find(u => u.username === newUsername);

    if (existingUser) {
        alert("Username sudah digunakan. Silakan pilih username lain.");
    } else {
        // Tambahkan pengguna baru ke daftar
        users.push({ username: newUsername, password: newPassword });
        alert("Registrasi berhasil. Silakan login dengan username dan password Anda.");
        document.getElementById("newUsername").value = "";
        document.getElementById("newPassword").value = "";
    }
}
</script>
</body>
</html> */}
