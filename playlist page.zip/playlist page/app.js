// app.js
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const app = express();


app.set('view engine', 'ejs');


app.use(bodyParser.urlencoded({ extended: true }));


app.use(express.static(__dirname + '/public'));

// Data playlist (contoh data)
const playlistData = [
    {
        title: 'Lagu 1',
        singer: 'Penyanyi 1',
        image: '/images/image1.jpg',
        youtubeLink: 'https://www.youtube.com/watch?v=video1'
    },
    {
        title: 'Lagu 2',
        singer: 'Penyanyi 2',
        image: '/images/image2.jpg',
        youtubeLink: 'https://www.youtube.com/watch?v=video2'
    },
    // Tambahkan data playlist lainnya
];

// Halaman utama playlist
app.get('/playlist', (req, res) => {
    res.render('playlist', { playlist: playlistData });
});

// Port server
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});
