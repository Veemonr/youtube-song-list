// app.js
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const app = express();


app.set('view engine', 'ejs');


app.use(bodyParser.urlencoded({ extended: true }));


app.use(express.static(__dirname + '/public'));

// Data playlist (contoh data)
const playlistData = [
    {
        title: 'Lagu 1',
        singer: 'Penyanyi 1',
        image: '/images/image1.jpg',
        youtubeLink: 'https://www.youtube.com/watch?v=video1'
    },
    {
        title: 'Lagu 2',
        singer: 'Penyanyi 2',
        image: '/images/image2.jpg',
        youtubeLink: 'https://www.youtube.com/watch?v=video2'
    },
    // Tambahkan data playlist lainnya
];



app.get('/playlist', (req, res) => {
    res.render('playlist', { playlist: playlistData });
});


app.get('/add-playlist', (req, res) => {
    res.render('add-playlist');
});


app.post('/add-playlist', (req, res) => {
    const newPlaylist = {
        title: req.body.title,
        singer: req.body.singer,
        image: req.body.image,
        youtubeLink: req.body.youtubeLink
    };
    playlistData.push(newPlaylist);
    res.redirect('/playlist');
});


app.get('/edit-playlist/:id', (req, res) => {
    const id = req.params.id;
    const playlist = playlistData[id];
    res.render('edit-playlist', { id, playlist });
});

// Memperbarui data playlist (Update)
app.post('/edit-playlist/:id', (req, res) => {
    const id = req.params.id;
    playlistData[id] = {
        title: req.body.title,
        singer: req.body.singer,
        image: req.body.image,
        youtubeLink: req.body.youtubeLink
    };
    res.redirect('/playlist');
});

// Menghapus data playlist (Delete)
app.get('/delete-playlist/:id', (req, res) => {
    const id = req.params.id;
    playlistData.splice(id, 1);
    res.redirect('/playlist');
});

// ...



// Port server
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});
